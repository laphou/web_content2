<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }?>

<?php include('header.php');?>
    <div class="grid__content">
      <div class="grid__content__title" style="background-image:url('http://localhost/testing/data/uploads/sky-clouds-weather-environment-concept-pqx7vna.jpg')">
        <div class="grid__content__title__fog"><h1><?php get_page_title();?></h1></div>
      </div>

      <div class="grid__content__content">
       <?php get_page_content();?>
      </div>
    </div>
<?php include('footer.php');?>