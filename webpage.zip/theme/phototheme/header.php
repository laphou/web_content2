<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title><?php get_page_title();?> | <?php get_site_name();?></title>
	  <link rel="stylesheet" href="<?php get_theme_url();?>/css/style.css" />
	  <?php get_header();?>
  </head>
  <body class="grid">
    <div class="grid__preload"></div>
    <div class="grid__menu">
            <a href="<?php get_site_url();?>" class="grid__menu__brand"><img src="<?php echo $logoshow ;?>"></a>

      <button class="grid__menu__btn"><div class="menu icon"></div></button>

      <ul class="grid__menu__nav">
       <?php get_navigation();?>
      </ul>

      <p class="grid__menu__copy">聯絡我們</p>
    </div>
