const menuBtn = document.querySelector('.grid__menu__btn');
const menuNav = document.querySelector('.grid__menu__nav');

function showMenu(){menuNav.classList.toggle('grid__menu__nav--show')}

menuBtn.addEventListener('click',showMenu);