<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }?>
   
<script src="<?php get_theme_url();?>/js/script.js"></script>

	  <?php get_footer();?>

<script>
	
	if(document.querySelector('.grid__menu__brand img').getAttribute('src')==''){
	document.querySelector('.grid__menu__brand img').setAttribute('src','<?php get_theme_url();?>/img/logo.png')
	}
	
		if(document.querySelector('.foto1')!==null && document.querySelector('.foto1').getAttribute('src')==''){
	document.querySelector('.foto1').setAttribute('src','<?php get_theme_url();?>/img/4.jpg')
	}
	
			if(document.querySelector('.foto2')!==null && document.querySelector('.foto2').getAttribute('src')==''){
	document.querySelector('.foto2').setAttribute('src','<?php get_theme_url();?>/img/3.jpg')
	}
	
	
	if(document.querySelector('.foto3')!==null && document.querySelector('.foto3').getAttribute('src')==''){
	document.querySelector('.foto3').setAttribute('src','<?php get_theme_url();?>/img/2.jpg')
	}
	
	
	if(document.querySelector('.grid__content__title')!==null && document.querySelector('.grid__content__title').style.backgroundImage == "url(\"\")"){
	document.querySelector('.grid__content__title').style.backgroundImage = "url('<?php get_theme_url();?>/img/2.jpg')";
	}
	
</script>
  </body>
</html>
