<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }?>

<?php include('header.php');?>

    <div class="grid__gallery">
      <a href="<?php echo  $foto1linkshow;?>" class="grid__gallery__item">
		  <img src="<?php echo $foto1show ;?>" class="foto1" alt="" />
        <h4>        <?php echo $foto1nameshow ;?>
</h4>
      </a>

      <a href="<?php echo  $foto2linkshow;?>" class="grid__gallery__item">
            <img src="<?php echo $foto2show ;?>" class="foto2" alt="" />
                <h4>        <?php echo $foto2nameshow ;?>
</h4>

          </a>

          <a href="<?php echo  $foto3linkshow;?>" class="grid__gallery__item">
                <img src="<?php echo $foto3show ;?>" class="foto3" alt="" />
     <h4>        <?php echo $foto3nameshow ;?>
</h4>
              </a>
    </div>

   <?php include('footer.php');?>