<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }?>

<?php

 $plugin_id = 'photoThemeSettings';
// Set up the folder name and its permissions
// Note the constant GSDATAOTHERPATH, which points to /path/to/getsimple/data/other/
$folder        = GSDATAOTHERPATH . '/' . $plugin_id . '/';
$foto1     = $folder . 'foto1.txt';
$foto1link     = $folder . 'foto1link.txt';
$foto1name     = $folder . 'foto1name.txt';
$foto2     = $folder . 'foto2.txt';
$foto2link     = $folder . 'foto2link.txt';
$foto2name     = $folder . 'foto2name.txt';
$foto3     = $folder . 'foto3.txt';
$foto3link     = $folder . 'foto3link.txt';
$foto3name     = $folder . 'foto3name.txt';

$logo    = $folder . 'logo.txt';
$pagebg    = $folder . 'pagebg.txt';


 $foto1show = file_get_contents($foto1);
 $foto1linkshow = file_get_contents($foto1link);
 $foto1nameshow = file_get_contents($foto1name);
 $foto2show = file_get_contents($foto2);
  $foto2linkshow = file_get_contents($foto2link);
 $foto2nameshow = file_get_contents($foto2name);

 $foto3show = file_get_contents($foto3);
  $foto3linkshow = file_get_contents($foto3link);
 $foto3nameshow = file_get_contents($foto3name);

  $logoshow = file_get_contents($logo);
 $pagebgshow = file_get_contents($pagebg);

 
;?>