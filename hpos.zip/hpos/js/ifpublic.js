// JavaScript Document
function transferdata(orderno,goodlist,results)
{
	var jsondata = {'order_sn':orderno,'goodlist':goodlist,'results':results};
	jQuery.ajax({
        type:'post',
        url:'http://tsp.szzt.com/hpos/insert.php',
        data:jsondata,
        dataType:'json',
        success:function(msg){
           
            if(msg == 'SUCCESS'){//成功后的操作
                
            }else{//失败

            }
        }
    })
}

var Extend = function(destination, source) {  
    for (var property in source) {  
        destination[property] = source[property];  
    }  
}  
var gettimes = function() { 
		
		var today; 
		today = new Date();
		var timeString;
		timeString =  today.getFullYear();
		var intmonth = [today.getMonth()+1];
		if(intmonth<10)
		   timeString += "0";
		timeString += intmonth;   
		var intday = today.getDate();
		if(intday<10)
		   timeString += "0";
		timeString += intday+" "; 
		
        var intHours = today.getHours(); 
        var intMinutes = today.getMinutes(); 
        var intSeconds = today.getSeconds(); 
		if(intHours<10)
		  timeString += "0";
		timeString += intHours+":"; 
		if(intMinutes<10)
		  timeString += "0";
		timeString += intMinutes+":"; 
		if(intSeconds<10)
		  timeString += "0";
		timeString += intSeconds; 
		
		return timeString;
		
		} 

var getdates = function() { 
		
		var today; 
		today = new Date();
		var dateString;
		dateString =  today.getFullYear();
		var intmonth = [today.getMonth()+1];
		if(intmonth<10)
		   dateString += "0";
		dateString += intmonth;   
		var intday = today.getDate();
		if(intday<10)
		   dateString += "0";
		dateString += intday;
		return dateString;
		
		} 		
		
var Class = {  
    create: function() {  
        return function() { this.Init.apply(this, arguments); }  
    }  
}  
var $ = function (id) {  
    return "string" == typeof id ? document.getElementById(id) : id;  
};
var addEventHandler = function(oTarget, sEventType, fnHandler) {  
    if (oTarget.addEventListener) {  

        oTarget.addEventListener(sEventType, fnHandler, false);  
    } else if (oTarget.attachEvent) {  
        oTarget.attachEvent("on" + sEventType, fnHandler);  
    } else {  
        oTarget["on" + sEventType] = fnHandler;  
    }  
};  

var removeEventHandler = function(oTarget, sEventType, fnHandler) {  
    if (oTarget.removeEventListener) {  
        oTarget.removeEventListener(sEventType, fnHandler, false);  
    } else if (oTarget.detachEvent) {  
        oTarget.detachEvent("on" + sEventType, fnHandler);  
    } else {   
        oTarget["on" + sEventType] = null;  
    }  
};  

function showmsg(parentdiv,controlname,tips)
{

	if($('msgdiv')) return;
	newDiv = document.createElement("div");
	newDiv.setAttribute('id','msgdiv');
	newDiv.style.textAlign="center";
	$(parentdiv).appendChild(newDiv);
	newDiv.innerHTML = "<span id='messagediv'>"+tips+"</span>";
	newDiv.style.position="absolute";
	newDiv.style.zIndex = "2";
	
	var m = $(controlname);

	var left = m.offsetLeft;
	var top = m.offsetTop;
	
	while(m.offsetParent.tagName.toUpperCase()!="DIV"&&m.offsetParent.tagName.toUpperCase()!="BODY")
	{
		
	 left += m.offsetParent.offsetLeft;
	 top+=m.offsetParent.offsetTop;
	 m = m.offsetParent;
	}
	
    
	top+=parseInt($(controlname).offsetHeight);
    
    top+=5;
	
	newDiv.style.left = left+"px";
	newDiv.style.top = top+"px";
	
	//newDiv.style.top = $(controlname).offsetTop+$(controlname).offsetHeight;
	
	
}
function closeself(bgDiv,newDiv)
{
	
	document.body.removeChild($(bgDiv));
	document.body.removeChild($(newDiv));
	
	window.parent.gotopage("teachoose");
}
function closeself2(bgDiv,newDiv)
{
	
	document.body.removeChild($(bgDiv));
	document.body.removeChild($(newDiv));
	
}
function closeself3(bgDiv)
{
	if($(bgDiv)!=null){
	document.body.removeChild($(bgDiv));
	
	}
	
}
function imgAlert(imgsrc,tips1,newDiv,newstyle,tips,type)
{
	var iWidth = 1024;
var iHeight =600;

this.bgObj=document.createElement("div");
bgObj.setAttribute('id','bgDiv');
bgObj.style.position="absolute";
bgObj.style.top="0";
bgObj.style.background="#c0c0c0";
bgObj.style.filter="progid:DXImageTransform.Microsoft.Alpha(style=3,opacity=25,finishOpacity=75)";
bgObj.style.opacity="1";
bgObj.style.left="0";
bgObj.style.overflow = "hidden";
bgObj.style.width=iWidth + "px";
bgObj.style.height=iHeight + "px";
bgObj.style.zIndex = "1";
document.body.appendChild(bgObj);
if(!newDiv)
{
	newDiv = document.createElement("div");
	newDiv.setAttribute('id','tipdiv');
	newDiv.style.textAlign="center";
   
	if(type=="button")
	{
		var a = "<img src='"+imgsrc+"'>";
		a+="<p >"+tips1+"</p>";
		a+="<p>"+tips+"</p><input type='button' value='确定' onclick='closeself("+bgObj.id+","+newDiv.id+")'>";
		
	newDiv.innerHTML = a;
	
	}
	else
	{
	newDiv.innerHTML = "<br><br><p>"+tips+"</p>";
	window.setTimeout("closeself2(\""+bgObj.id+"\",\""+newDiv.id+"\")", 1000)
	}
	document.body.appendChild(newDiv);
}
else
{
	
	var obj1 = newDiv.getElementsByTagName("div");
	
    for (var i=0; i<obj1.length; i++)
    {
		newDiv.removeChild(obj1[i]);
    }
		
}
 
newDiv.style.opacity="60";
newDiv.style.position="absolute";
newDiv.style.zIndex = "2";
newDiv.style.display = "block"; 
newDiv.style.overflow = "hidden";

newstyle = newstyle||{width:300,height:300,left:250,top:71};
if(newstyle)
{
  newDiv.style.width = newstyle.width+"px";//"300px";
  newDiv.style.height = newstyle.height+"px";//"300px";
  newDiv.style.left = newstyle.left+"px";//"250px";
  newDiv.style.top = newstyle.top+"px";//"90px";
  if(typeof(newstyle.background)=="undefined")
     newDiv.style.background = "#c0c0c0";
  else	 
  newDiv.style.background = newstyle.background;
}
}
function sAlert(newDiv,newstyle,tips,type)
{

var iWidth = 1024;
var iHeight =600;

this.bgObj=document.createElement("div");
bgObj.setAttribute('id','bgDiv');
bgObj.style.position="absolute";
bgObj.style.top="0";
bgObj.style.background="#c0c0c0";
bgObj.style.filter="progid:DXImageTransform.Microsoft.Alpha(style=3,opacity=25,finishOpacity=75)";
bgObj.style.opacity="0.6";
bgObj.style.left="0";
bgObj.style.overflow = "hidden";
bgObj.style.width=iWidth + "px";
bgObj.style.height=iHeight + "px";
bgObj.style.zIndex = "1";
document.body.appendChild(bgObj);
if(!newDiv)
{
	newDiv = document.createElement("div");
	newDiv.setAttribute('id','tipdiv1');
	newDiv.style.textAlign="center";
   
	if(type=="button")
	{
		
	newDiv.innerHTML = "<br><br><p >"+tips+"</p><br><input type='button' style='height:40px;background-color:#ffe287;' value='确定' onclick='closeself("+bgObj.id+","+newDiv.id+")'>"
	
	}
	else
	{
	newDiv.innerHTML = "<br><br><p>"+tips+"</p>";
	window.setTimeout("closeself2(\""+bgObj.id+"\",\""+newDiv.id+"\")", 1000)
	}
	document.body.appendChild(newDiv);
}
else
{
	
	var obj1 = newDiv.getElementsByTagName("div");
	
    for (var i=0; i<obj1.length; i++)
    {
		newDiv.removeChild(obj1[i]);
    }
		
}
 
newDiv.style.opacity="60";
newDiv.style.position="absolute";
newDiv.style.zIndex = "2";
newDiv.style.display = "block"; 
newDiv.style.overflow = "hidden";

newstyle = newstyle||{width:300,height:300,left:250,top:90};
if(newstyle)
{
  newDiv.style.width = newstyle.width+"px";//"300px";
  newDiv.style.height = newstyle.height+"px";//"300px";
  newDiv.style.left = newstyle.left+"px";//"250px";
  newDiv.style.top = newstyle.top+"px";//"90px";
  if(typeof(newstyle.background)=="undefined")
     newDiv.style.background = "#c0c0c0";
  else	 
  newDiv.style.background = newstyle.background;
}

}   
