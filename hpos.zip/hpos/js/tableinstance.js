// JavaScript Document
var BindAsEventListener = function(object, fun) {  

    var args = Array.prototype.slice.call(arguments,2);  
   
    return function(event) {  
        return fun.apply(object, [event || window.event].concat(args));  
    }  
}  
var Table = Class.create();  
Table.prototype = {  
    //��ʼ��  
    Init:function(obj,options){  
	    this.Document = document;
		this.Window = window;
        this.Table=$(obj);  
        if(!this.Table){return;}  
         
		this.Table.className = "ttable";  
        this.SetOptions(options);//���ò���  
          
        this.HoverColor=this.Options.hoverColor;  
        this.ActiveColor=this.Options.activeColor;  
        this.Hover=this.Options.hover;  
        this.Choose=this.Options.choose;  
        this.Multiple=this.Options.multiple;  
        this.Cancel=this.Options.cancel;  
        this.Title=this.Options.title;  
        this.DClick=this.Options.dclick;  
        this.OnClick=this.Options.onClick;  
		this.onKeymove = this.Options.onKeymove;
        this.OnCancel=this.Options.onCancel;  
        this.OnMove=this.Options.onMove;  
        this.OnDClick=this.Options.onDClick; 
		this.tableth = this.Options.tableth; 
        this.pageSize = this.Options.pageSize;
		this.setpage = this.Options.setpage;
		this.tdwidth = this.Options.tdwidth;
		this.colname = this.Options.colname;
		this.colformat = this.Options.colformat;
		
        this._AddMouseEvent();  //�����¼�  
		this._createShowHeader();
          
        this._CurrentRow=null; //��ǰ�ƶ���  
		this._CurrentIndex = -1;
		this._pageIndex = -1;//��ǰҳ
        this._Cursor = null;//���ݼ��α�
	
		this._maxpage = -1;
		this._dataobject = new Array(); 
		
        this.SelectedArray=new Array();//���û򷵻ر�ѡ���еļ���  
    },  
	
	//���ò���  
    SetOptions:function(options){  
        this.Options={  
            hoverColor:"#ffa800",        //�ƶ�ʱ����ɫ  
            activeColor:"#ffa800",       //ѡ��ʱ����ɫ  
            hover:false,                  //�Ƿ����ƶ��б���ɫ  
            choose:true,                //�Ƿ���ѡ��  
            multiple:false,             //�Ƿ�����ѡ,������Ctrl���Զ�ѡ,ȡ��������Ҫͬʱ����  
            title:true,                 //�Ƿ���ʾtitle  
            cancel:true,                //�Ƿ���ȡ������  
            dclick:true,                //�Ƿ�˫��
			pageSize:8,
			tableth:[],
			tdwidth:[],
			colname:[],
			colformat:[],
            onClick:function(){},       //ѡ��ʱ���ӷ���  
            onCancel:function(){},       //ȡ��ѡ��ʱ���ӷ�������ʱȡ�����ܱ��뿪��  
            onMove:function(){},         //����ƶ��¼� 
			onKeymove:function(){}, 
		    setpage:null,
            onDClick:function(){}       //˫��  
		
        };  
        Extend(this.Options,options||{});  
    },  
	
	 _createShowHeader:function()
{    
	//������ͷ�е��ĵ����� 
	   var node=this._GetParentNode();  
	    for(var i =node.rows.length-1;i>=0;i--)
		 {
			  node.deleteRow(i); 
		 }
        var row=document.createElement("tr");  
		if(this.tableth==null)
		return;
		
        for(var i=0;i<this.tableth.length+1;i++){  
            var cell=document.createElement("th");  
			cell.align="left";
			if(i==0)
			{
            cell.innerHTML=this.tableth[i]; 
			cell.width = this.tdwidth[i];
			cell.style.display= "none"; 
			
			}
			else if(i==1)
			{
				cell.innerHTML="���";
				cell.width = "70px";
			}
			else
			{
				if(this.tdwidth[i-1]==0)
				    cell.style.display= "none"; 
				  cell.innerHTML=this.tableth[i-1]; 
			      cell.width = this.tdwidth[i-1];
			}
			
			cell.className="tth";
            row.appendChild(cell);  
        }  
	   
        node.appendChild(row);  

}  ,
	 //���ӱ����¼�����  
    _AddMouseEvent:function(){  
	    addEventHandler(this.Window,"keydown",BindAsEventListener(this, this._KeyMove));  
		 addEventHandler(this.Document,"click",BindAsEventListener(this, this._MouseOutClick));  
		 addEventHandler(this.Table,"click",BindAsEventListener(this, this._MouseClick));

    },  
	
	 //��ȡ��ǰ�¼�����  
    _GetCurrentElem:function(e){  
        var elem = e.srcElement || e.target;  
        if(elem.tagName.toUpperCase()=="TD"){  
            return elem.parentNode;  
        }  
        if(elem.tagName.toUpperCase()=="TR"){  
            return elem;  
        }  
        return null;  
    },  
    prevpage:function(){
    	 
   	this._pageIndex--;
	this._CurrentIndex==-1;
	this.onKeymove();
	this.showall();
    },
    nextpage:function(){
    	 this._pageIndex++;
     	   this._CurrentIndex==-1;
     	   this.onKeymove();
     	   this.showall();
    },
	_KeyMove:function(e){
		
	//	document.selection? document.selection.empty() : //window.getSelection();  
      
	    var index = this._CurrentIndex;
		
		  if(this._CurrentIndex<0)
		return;
		
		if(document.activeElement.id!="")
		 return;
		switch (e.keyCode) {
     case 38 ://��
	    
      this.Table.rows[index].style.backgroundColor = "transparent";
      index=index>1?index-1:1;
	  this.Table.rows[index].style.backgroundColor = this.ActiveColor;
     this._CurrentIndex = index;
	 this.OnClick();  
      break;
     case 40 ://��
	
      var rowl=this.Table.rows.length-1;
	 
	    this.Table.rows[index].style.backgroundColor = "transparent";
     
      index=index<rowl?index+1:rowl;
       this.Table.rows[index].style.backgroundColor = this.ActiveColor;
	   this._CurrentIndex = index;
	     this.OnClick();  
      break;
	 case 39: //right
	    
	   this._pageIndex++;
	   this._CurrentIndex==-1;
	   this.onKeymove();
	   this.showall();
	  break; 
	 case 37: //left
	    this._pageIndex--;
		this._CurrentIndex==-1;
		this.onKeymove();
		this.showall();
		break; 
     default :
      return;
    }

		
	},
  
  
	 _MouseOutClick:function(e){  
         var elem=this._GetCurrentElem(e);  
		
        if(elem!=null){return;}  
		elem = e.srcElement || e.target;  
		
		if(elem.tagName.toUpperCase()=="INPUT"||elem.tagName.toUpperCase()=="BUTTON")
		   return;
		  var index = this._CurrentIndex;

		  if(this._CurrentIndex<0)
		return;
		if(this.Table.rows[index]!=undefined)
		   this.Table.rows[index].style.backgroundColor = "transparent";
		 this._CurrentIndex = -1;
		// this.OnClick(); 
		
		
    },  
    //ѡ���¼�  
    _MouseClick:function(e){  
        var elem=this._GetCurrentElem(e);  
		
        if(elem==null){return;}  
      
	    if(this._CurrentRow!=null)
		{
		  	
			  this._CurrentRow.style.backgroundColor="transparent";  
		}
		this._CurrentIndex = this._GetSelectedIndex(elem);
      
        elem.style.backgroundColor=this.ActiveColor;  
        this._CurrentRow = elem;
        this.OnClick();  
      
    },  
  
	//��ȡ��ǰ����������
	 _GetSelectedIndex:function(elem){  
        for(var i=0;i<this.Table.rows.length;i++){  
            if(elem==this.Table.rows[i]){  
                return i;  
            }  
        }  
        return -1;  
    },  
   
    //��ȡ�����ڸ��ڵ�  
    _GetParentNode:function(){  
	
        var nodes=this.Table.childNodes;  
	
        if(nodes.length>0){  
            for(var i=0;i<nodes.length;i++){  
                if(nodes[i].tagName.toUpperCase()=="TBODY"){  
				
                    return nodes[i];  
                }  
            }  
        }  
        return this.Table;  
    },  
	refreshfromsql:function(){
		var result = this._Cursor;
		delete this._dataobject;
		this._dataobject = new Array();
		
		for(var i=0; i<result.rows.length;i++)
		{
			this._dataobject[i] = result.rows.item(i);
		}
		//this._dataobject.length = result.rows.length;
		delete this._Cursor;
		this.setmaxpage();
		this.showall();
		
	},
	setmaxpage:function(){
	     if(this._dataobject.length<=0)
		 {
		    this._maxpage = 0;
		    return;
		 }
			 this._maxpage = Math.floor(this._dataobject.length/this.pageSize); 
			 
			 this._maxpage =( this._dataobject.length%this.pageSize)==0?this._maxpage:this._maxpage+1;
			 
	},
	showall:function(){
		
	
		var param = this.colname;
	
		var node=this._GetParentNode();  
	
		var result = this._dataobject;
		/*
	    if(this._pageIndex<1)
		   this._pageIndex = 1;
		if(this._pageIndex>this._maxpage)
		  this._pageIndex = this._maxpage;
		if(this.setpage)
		this.Document.getElementById(this.setpage).innerHTML =  this._pageIndex;*/
		if(this._maxpage == 0)
		{
			return;
		}
	   
	     this.DeleteAllRows();
	
		 for(var i=0;i<result.length;i++)
		 {
			  var arow=[];
			  var row = result[i];
		        for(var j=0;j<param.length;j++)
				{
			    arow.push(eval("row."+param[j]));
				}
				this.AddNewRow(arow);
				
		 }
		
	},
	 
	InsertNewRow0:function(content){
		
		
		var param = this.colname;
		
		var row = {};
		
		 for(var j =0;j<param.length;j++)
	     {
			eval("row."+param[j] +"=\"" +content[j]+"\"");
		 }
		
		if(this._dataobject.length%this.pageSize == 0)
		{
			this._maxpage++;
		}
		this._dataobject.unshift(row);
		
		this._pageIndex = 0;
		this.showall();
	},
	InsertNewRow:function(content){ 
		if(this._dataobject.length%this.pageSize == 0)
		{
			this._maxpage++;
			this._pageIndex = this._maxpage;
			this.DeleteAllRows();
			this.AddNewRow(content);			 
		}
		else
		{
		    this._pageIndex = this._maxpage;
		    this.showall();
		    this.AddNewRow(content);
		}
		
		var param = this.colname;
		
		var row = {};
		
		 for(var j =0;j<param.length;j++)
	     {
			eval("row."+param[j] +"=\"" +content[j]+"\"");
		 }
		
		this._dataobject.push(row);
		
		
	},
    //������,����Ϊ������������
    AddNewRow:function(content){ 
        var node=this._GetParentNode(); 
		var len = node.children.length;
		
        var row=document.createElement("tr");  
		
        for(var i=0;i<content.length+1;i++){  
            var cell=document.createElement("td");  
			cell.className="ttd";
		    if(i==0)
			{
			cell.style.display= "none";  
            cell.innerHTML=content[i];  
            row.appendChild(cell);  
			}
			else if(i==1)
			{
				
				cell.innerHTML=len;
				len++;
				row.appendChild(cell);  
			}
			else
			{
			
				 if(typeof(this.colformat[i-1])!="undefined"&&this.colformat[i-1]!=0)
				   
				    content[i-1] = Number(content[i-1]).toFixed(this.colformat[i-1]);	
				if(this.tdwidth[i-1]==0)
				    cell.style.display= "none"; 
				cell.innerHTML=content[i-1];  
                row.appendChild(cell);  
			}
        }  
        node.appendChild(row);  
		
    },  
    //ɾ��ѡ����  
    DeleteRow:function(){  
	  var node=this._GetParentNode();  
	   
	  if(this._CurrentIndex==-1)
	  return;
	 
		
	   var row  = node.rows[this._CurrentIndex];
	    row.style.backgroundColor="transparent"; 
		
	   node.deleteRow(this._CurrentIndex); 
	   if(this._dataobject.length<=1)
	   {
		   this._dataobject = [];
	   }
	   else
	   {
		  
		var inc = this.pageSize*(this._pageIndex-1)+this._CurrentIndex-1;  
		
		this._dataobject.splice(inc,1);
		this.setmaxpage();
		
		this.showall();
	   }
		
	   this._CurrentIndex = -1;
	    
    },  
	DeleteAllRows:function(){
		 var node=this._GetParentNode(); 
		
		 for(var i =node.rows.length-1;i>0;i--)
		 {
			  node.deleteRow(i); 
		 }
	},
    DeleteTH:function(){
		 var node=this._GetParentNode(); 
		
	     node.deleteRow(0); 
		 
	},
    //�޸���,����Ϊ������������,�����ö�ѡʱ��Ч  
    UpdateRow:function(fields,values){  
	 
         if(this._CurrentIndex==-1||this._dataobject==""||fields==""||values=="")
	  return;
     
	    var inc = this.pageSize*(this._pageIndex-1)+this._CurrentIndex-1;  
		
		var oldrow = this._dataobject[inc];
		var row = {};
		row = clone(oldrow);
		for(var i=0;i<fields.length;i++)
		{
		   eval("row."+fields[i] +"=\"" +values[i]+"\"");
		}
		this._dataobject[inc] = row;
	   
    },  
	//ȥ����ѡ��
	ClearRowSelection:function(){
		 var node=this._GetParentNode();  
	   
	  if(this._CurrentIndex==-1)
	  return;
	 
	
	var row  = node.rows[this._CurrentIndex];
	    row.style.backgroundColor="transparent"; 
	
	  
	   this._CurrentIndex = -1;
	}
   
};  