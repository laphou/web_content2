// JavaScript Document




function addnum()
{
	
	  var elem = event.srcElement || event.target;  
	
	   if(elem.tagName.toUpperCase()=="INPUT"){ 
	   
	    var tid = elem.getAttribute("tid");
		
		 var perprice = elem.getAttribute("perprice");
	    var t  = $("goods_num"+tid).innerHTML;
		
		t++;
		$("goods_num"+tid).innerHTML = t;
		t=$("totalnum").innerHTML;
		t++;
		 $("totalnum").innerHTML= t;
		 t = $("t"+tid).innerHTML;
		  t = parseInt(t);
		 t+=parseInt(perprice);
		 $("t"+tid).innerHTML=t;
		
		 t =  $("totalprice").innerHTML;
		 t = parseInt(t);
		 t+=parseInt(perprice);
		  $("totalprice").innerHTML = t;
		  
		  
	   }
}
function minusnum()
{
	var elem = event.srcElement || event.target;  
	
	   if(elem.tagName.toUpperCase()=="INPUT"){ 
	   
	    var tid = elem.getAttribute("tid");
		
		 var perprice = elem.getAttribute("perprice");
	    var t  = $("goods_num"+tid).innerHTML;
		
		if(t==0) return;
		t=parseInt(t)-1;
		
		$("goods_num"+tid).innerHTML = t;
		
		t=$("totalnum").innerHTML;
		t=parseInt(t)-1;
		 $("totalnum").innerHTML= t;
		 t = $("t"+tid).innerHTML;
		
		 t = parseInt(t)-parseInt(perprice);
		
		
		 $("t"+tid).innerHTML=t;
		
		 t =  $("totalprice").innerHTML;
		t = parseInt(t)-parseInt(perprice);
		
		  $("totalprice").innerHTML = t;
		  
		  
	   }
}

function orderpay()
{

	if( $("ordepaydiv")!=null)  
	{
		
		  if( $("ordepaydiv").style.display=="block")
		  {
			
		   $("ordepaydiv").style.display="none";
		  }
		  else  if( $("ordepaydiv").style.display=="none")
		   $("ordepaydiv").style.display="block";
		return;
	}
   //创建一个背景div
    tipdiv=document.createElement("div");
    tipdiv.setAttribute('id','ordepaydiv');
   // tipdiv.setAttribute('class','keyboardd');
    tipdiv.style.position="absolute";

    tipdiv.style.background="url(../img/paydiv.png)";
    //tipdiv.style.left="0";
    tipdiv.style.width= "223px";
    tipdiv.style.height= "122px";
    tipdiv.style.zIndex = "1000";
    tipdiv.style.left="520px";
    tipdiv.style.top="330px";
tipdiv.style.display="block";

     //tipdiv.style.border = "1px solid #FFFFFF";
      //tipdiv.style.border-radius = "10px";
    tipdiv.style.font= "18px '微软雅黑', 'Verdana'";
    document.body.appendChild(tipdiv);
	var a = "<table cellpadding=0 cellspacing='5px' border=0 width='80%' height='90%' align='center' valign='middle'><tr>"
    a += "<td height='50%' valign='middle' align='center'  id='cashpayb'>现金结算</td></tr>";
	a+="<tr ><td height='50%' valign='middle' align='center' id='weixinpayb'>微信结算</td></tr>";
	a+="</table>";
    tipdiv.innerHTML = a;
	// addEventHandler($("cashpayb"),"click",gotonext); 
	 
    // addEventHandler($("weixinpayb"),"click",weixinpayclick); 
	 var mobile = typeof orientation !== 'undefined';
	 
	 if(mobile){
		  addEventHandler($("cashpayb"),"touchstart",changebgcolor1); 
	      addEventHandler($("weixinpayb"),"touchstart",changebgcolor1); 
		   
		 
		}else{
		  addEventHandler($("cashpayb"),"mouseover",changebgcolor1); 
		  addEventHandler($("weixinpayb"),"mouseover",changebgcolor1); 
		  addEventHandler($("cashpayb"),"mouseout",changebgcolor2); 
		  addEventHandler($("weixinpayb"),"mouseout",changebgcolor2); 
		   
		}
		
	 addEventHandler($("cashpayb"),"click",gotonext); 
    addEventHandler($("weixinpayb"),"click",weixinpayclick); 
   // window.setTimeout("closeself3(\""+tipdiv.id+"\")", 200);


}

function hidediv()
{
	 var a = event.srcElement?event.srcElement:event.target;
	 if(a.id!="weixinpayb"&&a.id!="cashpayb"&&a.id!="orderclick")  
	 {
		
	    if($("ordepaydiv")!=null)
		   $("ordepaydiv").style.display="none";
	 }
	
}

function changebgcolor1()
{
	var elem = event.srcElement || event.target;  
	elem.style.backgroundColor="#eeeeee";
}
function changebgcolor2()
{
	var elem = event.srcElement || event.target;  
	elem.style.backgroundColor="transparent";
	
}


function gotonext()
{
	//ORDER_DETAIL
	
	var sqltablename = "TORDER_DETAIL";
	var sqltableitem = ["id","goods_num"];

	var insertvalue = new Array();
    parent._totalprice = $("totalprice").innerHTML;
	parent._totalnum = $("totalnum").innerHTML;
	for(var i=0;i<parent._totalrows;i++)
	{
		
		elem = document.getElementById("k"+i);;
		
		var databaseid = elem.getAttribute("databaseid");
		var rownum = $("goods_num"+i).innerHTML;
		
		//var databaseprice = elem.getAttribute("databaseprice");
	
		if(rownum!=0)
		{
			var row = new Array();
		    row.push(databaseid); 
		    row.push(rownum);
		  
		    insertvalue.push(row);
		}
	
		
		
	}
	
	sqlProvider.updateMultiRows(sqltablename,sqltableitem,insertvalue,function()
				{
					
					 window.parent.gotopage("pay");
			
				});
	
}
function returnclick()
{
	window.parent.gotopage("teachoose"); 
}

function weixinpayclick()
{
	var sqltablename = "TORDER_DETAIL";
	var sqltableitem = ["id","goods_num"];

	var insertvalue = new Array();
    parent._totalprice = $("totalprice").innerHTML;
	parent._totalnum = $("totalnum").innerHTML;
	for(var i=0;i<parent._totalrows;i++)
	{
		
		elem = document.getElementById("k"+i);;
		
		var databaseid = elem.getAttribute("databaseid");
		var rownum = $("goods_num"+i).innerHTML;
		
		//var databaseprice = elem.getAttribute("databaseprice");
	
		if(rownum!=0)
		{
			var row = new Array();
		    row.push(databaseid); 
		    row.push(rownum);
		  
		    insertvalue.push(row);
		}
	
		
		
	}
	
	sqlProvider.updateMultiRows(sqltablename,sqltableitem,insertvalue,function()
				{
					
					 window.parent.gotopage("weixinpay");
			
				});
}



function init()
{
	
	try{
	 this.sqlProvider = window.parent.sqlProvider;
	 sqlProvider = window.parent.sqlProvider;
	}
	catch(e){
	}
	parent._totalnum =0;
	var divinner="";
	sqlProvider.loadTable('SELECT TORDER_DETAIL.id,TORDER_DETAIL.goodsid,TORDER_DETAIL.goods_num,TEA_INFO.goods_name, TEA_INFO.goods_sellperprice FROM TORDER_DETAIL,TEA_INFO where TORDER_DETAIL.goodsid=TEA_INFO.id order by TORDER_DETAIL.id asc',[],function(result){
		var num = result.rows.length;
		 var count=0;
		 var ttotalnum=0;
		var ttotalprice=0;
		parent._totalrows = num;
		for(var i=0;i<num;i++)
	
	{
		
		var goodsname="";
		var goodsprice="";
		 var databaseid = "";
		 var databaseprice = "";
	      databaseid = result.rows.item(count).id;
		   goodsid = result.rows.item(count).goodsid;
		   goods_num = result.rows.item(count).goods_num;
			goodsname = result.rows.item(count).goods_name;
			 goods_sellperprice = result.rows.item(count).goods_sellperprice;
			 goodsprice = result.rows.item(count).goods_sellperprice;
			ttotalnum+=parseInt(goods_num);
            rowprice = Number(parseInt(goods_sellperprice)*parseInt(goods_num));
			ttotalprice+=rowprice;
		var k=i;
		
		 divinner +=  '<div class="outdiv">';
	  
       divinner +=    '<div databaseid="'+databaseid+'" clicknum="0" databaseprice="'+goods_sellperprice+'" id="k'+k.toString()+'" class="teaname" >'+goodsname+'</div>';
	   divinner +=    '    <div class="teanum"  id="b'+k.toString()+'"><input type="button" value="-" onclick="minusnum()" tid="'+k.toString()+'"  perprice="'+goodsprice+'"+/>&nbsp;&nbsp;&nbsp;&nbsp;<span id="goods_num'+k.toString()+'">'+goods_num+'</span>&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="+" onclick="addnum()" tid="'+k.toString()+'" perprice="'+goodsprice+'"/></div>';
       divinner +=    '    <div class="teaname"  id="n'+k.toString()+'">'+goodsprice+'</div>';
	    divinner +=    '    <div class="teaname"  id="t'+k.toString()+'">'+rowprice+'</div>';
       divinner += '</div>';
	   count++;
	   
	}
	//parent._totalnum = ttotalnum;
    
	$("dtealist").innerHTML = divinner;
	var div2 = "";
		 div2 +=  '<div class="outdiv">';
	  
       div2 +=    '<div class="teaname">商品名称</div>';
	   div2 +=    '    <div class="teanum">数量</div>';
       div2 +=    '    <div class="teaname">单价（元）</div>';
	    div2 +=    '    <div class="teaname">小计（元）</div>';
       div2 += '</div>';
	   $("dlist").innerHTML = div2;
	   $("totalnum").innerHTML = ttotalnum;
	   $("totalprice").innerHTML = ttotalprice;
	  
	});	
	
   addEventHandler($("orderclick"),"click",orderpay); 
   addEventHandler($("return"),"click",returnclick); 
  //  addEventHandler($("weixinpay"),"click",weixinpayclick); 
   
   
}

window.onclick = hidediv;
window.onload = init;