// JavaScript Document
var $ = function (id) {  
    return "string" == typeof id ? document.getElementById(id) : id;  
};





function addclick()
{
	 window.parent.gotopage("add");
}
function changestyle()
{
	parent._totalnum++;
	$("totalnum").innerHTML = parent._totalnum;
	var old = $("totalprice").innerHTML.slice(0,-1);

	//$("totalprice").innerHTML
	var elem = event.srcElement || event.target;  
	
        if(elem.tagName.toUpperCase()=="DIV"){  
		//alert(elem.attr("databaseid"));
		var clicknum = elem.getAttribute("clicknum");
		
		clicknum++;
		elem.setAttribute("clicknum",clicknum);
		
		var price = elem.getAttribute("databaseprice");
		old = parseInt(old)+parseInt(price);
		$("totalprice").innerHTML = old+"元";
		if(elem.className=="choose-btn")
		     elem.className = "choose-btnclick";
		//else if(elem.className=="choose-btnclick")
		  //   elem.className = "choose-btn";
		  
        }  
       
}
function gotonext()
{
	
	//ORDER_DETAIL
	var sqltablename = "TORDER_DETAIL";
	var sqltableitem = ["goodsid","goods_num"];
	var eles=document.getElementsByClassName("choose-btnclick");
	var insertvalue = new Array();
    if(eles.length==0)
	{
		sAlert(null,{width:300,height:150,left:320,top:160},"下单前请先选择商品","auto");
		return;
	}
	for(var i=0;i<eles.length;i++)
	{		
		elem = eles[i];
		
		var clicknum = elem.getAttribute("clicknum");
		var databaseid = elem.getAttribute("databaseid");
		var row = new Array();
		row.push(databaseid); 
		row.push(clicknum);
	
		insertvalue.push(row);
		
	}
	
	sqlProvider.insertMultiRows(sqltablename,sqltableitem,insertvalue,function(id)
				{
					 window.parent.gotopage("goodscart");
			
				});
	
	
}
function init()
{
	
	
	 this.sqlProvider = window.parent.sqlProvider;
	 sqlProvider = this.sqlProvider;
	
	this.sqlProvider.loadTable('DELETE FROM TORDER_DETAIL');
	this.sqlProvider.loadTable('DELETE FROM TEA_INFO');
	this.sqlProvider.loadTable('insert into TEA_INFO (goods_name,goods_sellperprice) values ("原味奶茶","5")');
	this.sqlProvider.loadTable('insert into TEA_INFO (goods_name,goods_sellperprice) values ("丝袜奶茶","6")');
	this.sqlProvider.loadTable('insert into TEA_INFO (goods_name,goods_sellperprice) values ("红豆冰奶茶","8")');
	this.sqlProvider.loadTable('insert into TEA_INFO (goods_name,goods_sellperprice) values ("绿豆冰奶茶","9")');
	this.sqlProvider.loadTable('insert into TEA_INFO (goods_name,goods_sellperprice) values ("原味红茶","10")');
	this.sqlProvider.loadTable('insert into TEA_INFO (goods_name,goods_sellperprice) values ("原味绿茶","11")');
	this.sqlProvider.loadTable('insert into TEA_INFO (goods_name,goods_sellperprice) values ("原味冰红茶","10")');
	this.sqlProvider.loadTable('insert into TEA_INFO (goods_name,goods_sellperprice) values ("原味冰绿茶","11")');
	this.sqlProvider.loadTable('insert into TEA_INFO (goods_name,goods_sellperprice) values ("香芋红茶","10")');
	this.sqlProvider.loadTable('insert into TEA_INFO (goods_name,goods_sellperprice) values ("香芋绿茶","11")');
	var divinner="";
	this.sqlProvider.loadTable('SELECT id,goods_name,goods_sellperprice FROM TEA_INFO order by id desc',[],function(result){
		
		var num = result.rows.length;
		 var count=0;
		 var colmax = 4;
		 var rowmax = Math.floor(num/4)+1;
		
		for(var i=0;i<rowmax;i++)
	for(var j=0;j<colmax;j++)
	{
		var k = i*3+j;
		var goodsname="";
		var goodsprice="";
		 var databaseid = "";
		 var databaseprice = "";
		if(count<num)
		{
			
			 goodsname = result.rows.item(count).goods_name;
			// databaseid = result.rows[count]["id"];
			 databaseid = result.rows.item(count).id;
			 databaseprice = result.rows.item(count).goods_sellperprice;
			 goodsprice = result.rows.item(count).goods_sellperprice+"元";
			 divinner +=  '<div class="choose">';
            
		}
		else
		{
			 goodsname = "hidden";
			 goodsprice = "0元";
			 divinner +=  '<div class="choose_hidden">';
           
		}
		
	  
       divinner +=    '<div databaseid="'+databaseid+'" clicknum="0" databaseprice="'+databaseprice+'" id="k'+k.toString()+'" class="choose-btn" onclick="changestyle()">'+goodsname+'</div>';
	  
       divinner +=    '    <div class="pay"  id="p'+k.toString()+'">'+goodsprice+'</div>';
       divinner += '</div>';
	   count++;
	   
	}
	parent._totalnum = 0;

	$("dtealist").innerHTML = divinner;
	
	   // $("datacount").innerHTML = result.rows.length;
		//$("pagecount").innerHTML = Math.floor(result.rows.length/this.pageSize)+1;
		//this.table._Cursor = result;
		//this.table._pageIndex = 0;
		//this._maxpage = -1;
		//this.table.refreshfromsql();
	});	
	
   addEventHandler($("orderclick"),"click",gotonext); 
}

window.onload = init;