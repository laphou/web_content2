// JavaScript Document
var $ = function (id) {  
    return "string" == typeof id ? document.getElementById(id) : id;  
}




function showcashpaydiv()
{
	var innerdiv="";
	innerdiv+="<div class=''>已收现金：";
	innerdiv+="<input type='text'/>"
	innerdiv+="</div>"
	innerdiv+="<div class=''>找零：";
	innerdiv+="<span id='changes'>0</span>"
	innerdiv+="</div>"
    innerdiv+="<div class=''>";
	innerdiv+="<input type='button' value='确定'/>"
	innerdiv+="</div>"
	$("cashpaydiv").innerHTML = innerdiv;
	$("cashpaydiv").style.display = "block";
}
function cancelclick()
{
	 window.parent.gotopage("teachoose");
}

function getorderid(id)
{
	var num = id.toString().length;
	var prefix = "";
	if(num<8)
	{
	 for(var i=0;i<8-num;i++)
	   prefix+="0";
	}
	return (prefix+id.toString());
}

function sureclick()
{
	printorder();
}


function printorder()
{
	
	
 
	var str = "        日结清单\n";
	str+="订单笔数："+$("ordernum").innerHTML+"\n";
	str+="卖出奶茶数量（杯）："+$("teanum").innerHTML+"\n";
	str+="总金额："+$("totalprice").innerHTML+"\n";
	
	str+="\n";
	
	var type = 2;
	doPrintReception(type,str);
	
	
	
	//doPrintReception(type,str);
  
    	
	//TDS.Device.PrinterService.ReceiptPrinter.sigPrintFormCompleted.connect(onPrintFromCompleted);
	//TDS.Device.PrinterService.ReceiptPrinter.printForm("payTitle",str);			
}

function init()
{
	
	 this.sqlProvider = window.parent.sqlProvider;
	 sqlProvider = window.parent.sqlProvider;
	 var dates=getdates();
	
	this.sqlProvider.loadTable("SELECT * FROM ORDER_INFO WHERE SUBSTR(ordertime,1,8)=?",[dates],function(result){
	
		if(result.rows.length!=0)
		{
			this.sqlProvider.createTable('CREATE TABLE IF NOT EXISTS ORDER_INFO(id INTEGER NOT NULL PRIMARY KEY,tid VARCHAR(10),totalprice DOUBLE(0,2),totalnum INTEGER, membercard VARCHAR(10),paymethod INTEGER,ordertime VARCHAR(20))'); //0表示会员卡积分抵扣 1表示付现金 2表示还未付款
			var sale_totalnumber=0;
			var sale_goodstotalprice=0;
			for(var i=0;i<result.rows.length;i++)
			{
					
					sale_totalnumber=parseInt(sale_totalnumber)+parseInt(result.rows.item(i).totalnum);
					sale_goodstotalprice=parseFloat(sale_goodstotalprice)+parseFloat(result.rows.item(i).totalprice);
							
			}
			$('ordernum').innerHTML=result.rows.length; 
			$("teanum").innerHTML=sale_totalnumber; 
			$("totalprice").innerHTML=sale_goodstotalprice; 
			
		}
		else
		{
			$('ordernum').innerHTML=0; 
			$("teanum").innerHTML=0; 
			$("totalprice").innerHTML=0; 
			
		}
	});

	

   addEventHandler($("sureclickdiv"),"click",sureclick); 
   addEventHandler($("cancelclickdiv"),"click",cancelclick); 
}

window.onload = init;

