function postdata(){
	
    var order_sn = new Date().getTime();
    var goodlist =  new Array();
    var len = jQuery("#dtealist").find('.outdiv').length;
    var total_nums = 0;
    var total_fee = 0;
    var money1 = 0;
    var money2 = 0;
    for(var i=0;i<len;i++){
		goodlist[i] = new Object;
		goodlist[i].goods_name = jQuery("#dtealist .outdiv").find("#k"+i).text();
		goodlist[i].goods_num = jQuery("#dtealist .outdiv").find("#goods_num"+i).text();
		goodlist[i].goods_price = jQuery("#dtealist .outdiv").find("#n"+i).text();
		total_nums = total_nums*1+goodlist[i]['goods_num']*1;
		total_fee = total_fee*1+goodlist[i]['goods_num']*goodlist[i]['goods_price']*1;

	}
	var jsondata = {'order_sn':order_sn,'goodlist':goodlist,'total_fee':total_fee,'total_nums':total_nums,'money1':money1,'money2':money2};


    jQuery.ajax({
        type:'post',
        url:'http://tsp.szzt.com/hpos/insert.php',
        data:jsondata,
        dataType:'json',
        success:function(msg){
            alert(msg);
            if(msg == 'SUCCESS'){//成功后的操作
                
            }else{//失败

            }
        }
    })
}