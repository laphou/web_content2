var ClassDGS ={
	   create: function() {
                return function() { this.Init.apply(this, arguments); }  
         }  
}

var DGS = ClassDGS.create(); 

DGS.prototype = { 
	Init:function()
	{
		this.service=null;
		if( window.TAP != null )
    {
    	this.service = TAP.Dgs;
      return;
    }
    if( window.parent.TAP != null )
    {
        this.service =  parent.TAP.Dgs;
        return;
    }
    if( window.parent.parent.TAP != null )
    {
        this.service =  parent.parent.TAP.Dgs;
        return;
    }
    if( window.parent.parent.parent.TAP != null )
    {
        this.service =  parent.parent.parent.TAP.Dgs;
        return;
    }   
	}
	
	
}


