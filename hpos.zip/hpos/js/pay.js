// JavaScript Document
var $ = function (id) {  
    return "string" == typeof id ? document.getElementById(id) : id;  
}

function keyboardtip(bid)
{


//创建一个背景div
this.tipdiv=document.createElement("div");
tipdiv.setAttribute('id','tipdiv');
tipdiv.setAttribute('class','keyboardd');
tipdiv.style.position="absolute";

tipdiv.style.background="#FFFFFF";
//tipdiv.style.left="0";
tipdiv.style.width= "55px";
tipdiv.style.height= "38px";
tipdiv.style.zIndex = "1000";


switch(Number(bid))
{
case 1:
tipdiv.style.left="525px";
tipdiv.style.top="50px";
break;
case 2:
tipdiv.style.left="620px";
tipdiv.style.top="50px";
break;
case 3:
tipdiv.style.left="725px";
tipdiv.style.top="50px";
	break;
case 4:
	tipdiv.style.left="820px";
tipdiv.style.top="50px";
	break;
case 5:
	tipdiv.style.left="525px";
tipdiv.style.top="120px";
	break;
case 6:
tipdiv.style.left="620px";
tipdiv.style.top="120px";
	break;
case 7:
	tipdiv.style.left="725px";
tipdiv.style.top="120px";
	break;
case 8:
	tipdiv.style.left="820px";
tipdiv.style.top="120px";
	break;
case 9:
	tipdiv.style.left="525px";
tipdiv.style.top="195px";
	break;
case 0:
	tipdiv.style.left="620px";
tipdiv.style.top="195px";
	break;
}

//tipdiv.style.border = "1px solid #FFFFFF";
//tipdiv.style.border-radius = "10px";
//tipdiv.style.font= "25px '微软雅黑', 'Verdana'";
document.body.appendChild(tipdiv);
tipdiv.innerHTML = bid;
window.setTimeout("closeself3(\""+tipdiv.id+"\")", 200);
}   


function showcashpaydiv()
{
	var innerdiv="";
	innerdiv+="<div class=''>已收现金：";
	innerdiv+="<input type='text'/>"
	innerdiv+="</div>"
	innerdiv+="<div class=''>找零：";
	innerdiv+="<span id='changes'>0</span>"
	innerdiv+="</div>"
    innerdiv+="<div class=''>";
	innerdiv+="<input type='button' value='确定'/>"
	innerdiv+="</div>"
	$("cashpaydiv").innerHTML = innerdiv;
	$("cashpaydiv").style.display = "block";
}
function cancelclick()
{
	 window.parent.gotopage("teachoose");
}

function getorderid(id)
{
	var num = id.toString().length;
	var prefix = "";
	if(num<8)
	{
	 for(var i=0;i<8-num;i++)
	   prefix+="0";
	}
	return (prefix+id.toString());
}

function sureclick()
{
	if($("actualprice").value=="")
	{
		$("actualprice").placeholder="请输入实收金额";
		//$("actualprice").focus();
	  return;
	}
	if(parseInt($("actualprice").value)<parseInt(parent._totalprice))
	{
		$("actualprice").value="";
		$("actualprice").placeholder="实收金额不能小于应收金额";
	//	$("actualprice").focus();
	  return;
	}
	if(isNaN($("actualprice").value))
	{
			$("actualprice").value="";
		$("actualprice").placeholder="只能输入数字";
		//$("actualprice").focus();
	  return;
	}
	var t = parseInt($("actualprice").value)-parseInt(parent._totalprice);
		
		$("changes").innerHTML=t;
	
		 $("actualprice").setAttribute("readOnly",'true');
	sqltablename = "ORDER_INFO";
	sqltableitem = ["totalprice","totalnum","paymethod","tid","ordertime"];
	var insertvalue = new Array();
	insertvalue.push(parent._totalprice);
	insertvalue.push(parent._totalnum);
	insertvalue.push("1");
	
	//select id 出来
	var loadstring = "select max(id) as mid from "+sqltablename;
	
	sqlProvider.loadTable(loadstring,[],function(result){	
	
	  if(result.rows.length==0)
	  {
		
	  parent._orderno = getorderid("0");
	  }
	  else
	  {
		  
		 if(result.rows.item(0).mid==null) parent._orderno = getorderid("0");
		 else  parent._orderno = getorderid(parseInt(result.rows.item(0).mid)+1);
	  }
	  insertvalue.push( parent._orderno );
	  var times = gettimes();
	insertvalue.push(times);
	 sqlProvider.insertRow(sqltablename,sqltableitem,insertvalue,function(id)
	{
		
		var sqls = "insert into ORDER_DETAIL(orderid,goodsid,goods_num)  select "+id+",goodsid,goods_num from TORDER_DETAIL";
		
		sqlProvider.loadTable(sqls);
		$("sureclickdiv").className = "suredisabled";
		
		$("divchanges").style.visibility="visible";
		removeEventHandler($("sureclickdiv"),"click",sureclick); 
		//removeEventHandler($("cancelclickdiv"),"click",cancelclick); 
		$("cancelclickdiv").innerHTML="返回";
		 sAlert(null,{width:400,height:180,left:320,top:260},"打印完毕之后点击确定","button"); 
		//addEventHandler($("cancelclickdiv"),"click",cancelclick);
		printorder();
		
	});
  
    
	});
}

function showncreditsdiv()
{
	var innerdiv="";
	innerdiv+="<div>会员卡号：";
	innerdiv+="<input type='text'/>"
	innerdiv+="</div>"
	innerdiv+="<div>";
	innerdiv+="<input type='button' value='确定'/>"
	innerdiv+="</div>"
	innerdiv+="<div id='creditsnum' style='display:none'>积分数";
	innerdiv+="<span id='creditsnums'>0</span>"
	innerdiv+="</div>"
	innerdiv+="<div id='creditspaysure' style='display:none'>是否需要积分兑换";
	innerdiv+="<input type='button' value='是' onclick='creditspaysureclick()'/><input type='button' value='否' onclick='creditspaycancel'/>"
	innerdiv+="</div>"
	$("creditspaydiv").innerHTML = innerdiv;
	$("creditspaydiv").style.display = "block";
}

function printorder()
{
	
	var orderno = parent._orderno;
	var printstr = "";
	var tgoods_name ="";
	var tgoods_perprice = 0;
	var tgoods_num = 0;

	
	var loadstring = "select goods_name,goods_sellperprice,goods_num  from TEA_INFO,TORDER_DETAIL where TEA_INFO.id=TORDER_DETAIL.goodsid and goods_num!=0 order by TORDER_DETAIL.id asc";
	
	sqlProvider.loadTable(loadstring,[],function(result){
		
	  if(result.rows.length==0)
	  {
	     console.log("error");
	  }
	  else
	  {
		  var goodlist =  new Array();
		  for(var i=0;i<result.rows.length;i++)
		  {
			 
			   tgoods_name = result.rows.item(i).goods_name;
			   tgoods_perprice = result.rows.item(i).goods_sellperprice;
			  tgoods_num = result.rows.item(i).goods_num;
			  printstr += (i+1).toString()+"    "+tgoods_name+"      "+tgoods_num+"     "+ tgoods_perprice+"\n";
			  goodlist[i] = new Object;
		      goodlist[i].goods_name = tgoods_name;
		      goodlist[i].goods_num = (i+1).toString();
		      goodlist[i].goods_price = tgoods_perprice;
		  }
		  
		  var results="行数："+parent._totalrows+" 件数："+parent._totalnum+" 合计："+parent._totalprice+"元\n现金："+$("actualprice").value+"元  找零："+$("changes").innerHTML+"元";
	var str = "        欢迎光临奶茶店\n";
	str+="单号:"+orderno+"\n";
	str+="=============================\n";
	str+="序号   商品名称     数量     单价\n";
	str+="=============================\n";
	str+=printstr;
	str+="=============================\n";
	str+=results;
	str+="\n";
	
	var type = 2;
	transferdata(orderno,goodlist,results);
	doPrintReception(type,str);
	
	  }});
	
	
	
	//doPrintReception(type,str);
  
    	
	//TDS.Device.PrinterService.ReceiptPrinter.sigPrintFormCompleted.connect(onPrintFromCompleted);
	//TDS.Device.PrinterService.ReceiptPrinter.printForm("payTitle",str);			
}



function init()
{
	//$("actualprice").focus();
	var a = new KeyBoard(sureclick);
	$("totalprice").innerHTML = parent._totalprice;
	try{
	 this.sqlProvider = window.parent.sqlProvider;
	 sqlProvider = window.parent.sqlProvider;
	}
	catch(e){
	}
	

   addEventHandler($("sureclickdiv"),"click",sureclick); 
   addEventHandler($("cancelclickdiv"),"click",cancelclick); 
  
}

window.onload = init;